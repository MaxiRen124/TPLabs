package generators;

public interface IGenerator {
	String getName();
	long getElement(int i, int j);
}
