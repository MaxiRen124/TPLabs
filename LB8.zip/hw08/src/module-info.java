/**
 * 
 */
/**
 * @author Max
 *
 */
module hw08 {
	requires java.desktop;
}